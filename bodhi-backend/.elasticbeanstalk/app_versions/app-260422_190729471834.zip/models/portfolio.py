from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class PortfolioItem(Base):
    __tablename__ = "portfolio_items"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"))
    symbol = Column(String, index=True)
    quantity = Column(Integer, default=0)
    average_buy_price = Column(Float, default=0.0)
    
    owner = relationship("User")

class Transaction(Base):
    __tablename__ = "transactions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"))
    type = Column(String)  # "BUY" or "SELL"
    symbol = Column(String)
    quantity = Column(Integer)
    price = Column(Float)
    total_value = Column(Float)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    owner = relationship("User")
    status = Column(String, default="EXECUTED") # Can be "EXECUTED", "PENDING_AMO", or "REJECTED"